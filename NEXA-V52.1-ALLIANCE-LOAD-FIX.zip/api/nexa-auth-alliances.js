const SUPABASE_URL =
  process.env.SUPABASE_URL || 'https://dfxcxboxrkfmrnsgpyin.supabase.co';

const SUPABASE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  'sb_publishable_HTd6T3L8WuN_owZwPUjE1Q_glB9YWM-';

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  // V52 frontend calls this endpoint with POST.
  if (req.method !== 'POST') {
    return res.status(405).json({
      error: 'Method not allowed',
    });
  }

  try {
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/alliances?select=id,tag,is_active&order=tag.asc`,
      {
        method: 'GET',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        cache: 'no-store',
      }
    );

    const data = await response.json().catch(() => []);

    if (!response.ok) {
      console.error('Alliance load error:', data);
      return res.status(response.status).json({
        error: 'Could not load alliances.',
        details: data,
      });
    }

    const alliances = Array.isArray(data)
      ? data.filter((alliance) => alliance.is_active !== false)
      : [];

    return res.status(200).json({
      alliances,
    });
  } catch (error) {
    console.error('NEXA alliance endpoint error:', error);
    return res.status(500).json({
      error: 'Could not load alliances.',
    });
  }
}
