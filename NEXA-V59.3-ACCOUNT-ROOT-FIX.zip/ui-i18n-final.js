(function(){
 const L=()=>NEXA_I18N.device();
 const tr=(k)=>NEXA_I18N.t(L(),k);
 const MAP={
  "LIVE":"live","View Event":"viewEvent","Apply":"apply","Apply →":"apply",
  "View Prep":"viewPrep","Fill Prep":"fillPrep","Claim Account":"claimAccount",
  "State Assignments":"stateAssignments","Puzzle & Presidency":"puzzlePresidency",
  "Transfers":"transfers","TRANSFER":"transfers","Back Home":"backHome",
  "My Submissions":"mySubmissions","Admin":"admin"
 };
 function walk(){
   document.querySelectorAll("a,button,.badge,.pill,.eyebrow,.nav-link").forEach(el=>{
     const raw=(el.textContent||"").trim();
     if(MAP[raw] && !el.dataset.nexaUiI18n){
       el.textContent=tr(MAP[raw]) + (raw.endsWith("→")?" →":"");
       el.dataset.nexaUiI18n="1";
     }
   });
 }
 document.addEventListener("DOMContentLoaded",()=>{
   try{NEXA_I18N.setDir(L());walk();new MutationObserver(walk).observe(document.body,{childList:true,subtree:true});}catch(_){}
 });
})();

/* ==========================================================
   NEXA v59.3 — ACCOUNT ROOT FIX
   One source of truth: Supabase player_accounts.
   No DOM scraping. No dependency on the Accounts modal.
   ========================================================== */
(function(){
'use strict';

const SUPABASE_URL='https://dfxcxboxrkfmrnsgpyin.supabase.co';
const SUPABASE_KEY='sb_publishable_HTd6T3L8WuN_owZwPUjE1Q_glB9YWM-';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

let client=null, accounts=[], selectedId=null, loading=null;

function getClient(){
  if(client) return client;
  if(!window.supabase?.createClient) return null;
  client=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
  return client;
}
function tagOf(a){ return a?.alliances?.tag || a?.custom_alliance_tag || 'Not Listed'; }
function initials(name){
  const p=String(name||'NEXA').trim().split(/\s+/).filter(Boolean);
  return (p.length>1?p[0][0]+p[1][0]:(p[0]||'NX').slice(0,2)).toUpperCase();
}
function avatarData(name){
  const t=initials(name);
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180">
  <defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#24315f"/><stop offset="1" stop-color="#15192f"/></linearGradient></defs>
  <rect width="100%" height="100%" rx="90" fill="url(#g)"/>
  <text x="50%" y="57%" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="62" fill="#c9b4ff">${esc(t)}</text>
  </svg>`;
  return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
}
function active(){
  if(!accounts.length) return null;
  const stored=localStorage.getItem('nexa_active_account_id');
  return accounts.find(a=>String(a.id)===String(stored)) || accounts.find(a=>a.is_main) || accounts[0];
}
async function fetchAccounts(force=false){
  if(loading && !force) return loading;
  loading=(async()=>{
    const c=getClient();
    if(!c) return [];
    const {data:{session}}=await c.auth.getSession();
    if(!session?.user){ accounts=[]; return []; }
    const {data,error}=await c.from('player_accounts')
      .select('id,in_game_name,player_id,alliance_id,custom_alliance_tag,is_main,alliances(tag)')
      .eq('user_id',session.user.id)
      .order('created_at');
    if(error){ console.error('NEXA account root load:',error); return accounts; }
    accounts=(data||[]).map((a,i)=>({...a,is_main:a.is_main===true || i===0}));
    window.nexaAccountsCache=accounts;
    syncHome();
    return accounts;
  })();
  try{return await loading;} finally{loading=null;}
}
function syncHome(){
  const a=active();
  const img=$('nexa-profile-launcher-photo');
  const name=$('nexa-profile-launcher-name');
  const badge=$('nexa-profile-launcher-badge');
  const count=$('nexa-profile-launcher-count');
  if(!a){
    if(name) name.textContent='ADD ACCOUNT';
    if(badge) badge.textContent='PROFILE';
    if(count) count.classList.add('hidden');
    return;
  }
  if(img){img.src=a.profile_photo_url||avatarData(a.in_game_name);img.style.display='block';}
  if(name){
    const parts=[String(a.in_game_name||'MY PROFILE').toUpperCase()];
    const tag=tagOf(a);
    if(tag && tag!=='Not Listed') parts.push(String(tag).toUpperCase());
    if(a.player_id) parts.push('ID '+a.player_id);
    name.textContent=parts.join(' • ');
  }
  if(badge) badge.textContent='MAIN';
  if(count){
    const extra=Math.max(0,accounts.length-1);
    count.textContent=String(accounts.length);
    count.classList.toggle('hidden',extra===0);
  }
}
function passport(a){
  $('nexa-v593-passport')?.remove();
  if(!a) return;
  const modal=$('nexa-account-constellation');
  if(!modal) return;
  const s=document.createElement('section');
  s.id='nexa-v593-passport';
  s.innerHTML=`<div class="nexa-v593-passport-card">
    <img src="${avatarData(a.in_game_name)}" alt="">
    <div><span>PROFILE PASSPORT</span><strong>${esc(a.in_game_name)}</strong>
    <small>${esc(tagOf(a))}${a.player_id?' • ID '+esc(a.player_id):''}</small></div>
  </div>`;
  modal.appendChild(s);
}
function render(){
  const system=$('nexa-constellation-system');
  if(!system) return;
  const main=active();
  const others=main?accounts.filter(a=>String(a.id)!==String(main.id)):accounts;
  const pos=[[82,31],[79,72],[21,72],[18,31]];
  let html='<span class="nexa-constellation-orbit one"></span><span class="nexa-constellation-orbit two"></span>';
  if(main){
    html+=`<button type="button" class="nexa-account-planet main" data-v593-account="${esc(main.id)}">
      <img src="${avatarData(main.in_game_name)}" alt="">
      <span class="nexa-account-planet-name">${esc(main.in_game_name)}</span>
      <span class="nexa-account-planet-type">MAIN</span></button>`;
  }
  others.slice(0,4).forEach((a,i)=>{
    const p=pos[i];
    html+=`<button type="button" class="nexa-account-planet alt" style="left:${p[0]}%;top:${p[1]}%" data-v593-account="${esc(a.id)}">
      <img src="${avatarData(a.in_game_name)}" alt="">
      <span class="nexa-account-planet-name">${esc(a.in_game_name)}</span>
      <span class="nexa-account-planet-type">ACCOUNT</span></button>`;
  });
  if(accounts.length<5){
    const p=pos[Math.min(others.length,3)]||[50,14];
    html+=`<button type="button" id="nexa-v593-add" class="nexa-account-planet alt nexa-add-planet" style="left:${p[0]}%;top:${p[1]}%">
      <span class="nexa-add-planet-symbol">+</span><span class="nexa-account-planet-name">ADD ACCOUNT</span></button>`;
  }
  system.innerHTML=html;
  $('nexa-constellation-manage')?.style.setProperty('display','none');
  passport(main);
}
async function open(){
  const modal=$('nexa-account-constellation');
  if(!modal) return;
  modal.classList.add('open'); modal.setAttribute('aria-hidden','false');
  await fetchAccounts(true);
  render();
}
function openAccounts(){
  $('nexa-account-constellation')?.classList.remove('open');
  const m=$('accounts-modal');
  if(m){m.style.visibility='';m.style.pointerEvents='';m.classList.add('open');m.setAttribute('aria-hidden','false');}
}
function choose(id){
  const a=accounts.find(x=>String(x.id)===String(id)); if(!a)return;
  localStorage.setItem('nexa_active_account_id',String(a.id));
  selectedId=a.id; syncHome(); render(); passport(a);
}

document.addEventListener('click',e=>{
  if(e.target.closest?.('#nexa-profile-launcher')){
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();open();return;
  }
  if(e.target.closest?.('#nexa-v593-add')){
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();openAccounts();return;
  }
  const p=e.target.closest?.('[data-v593-account]');
  if(p){
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
    choose(p.getAttribute('data-v593-account')); return;
  }
},true);

function boot(){
  fetchAccounts(true).then(()=>syncHome());
  const list=$('accounts-list');
  if(list) new MutationObserver(()=>setTimeout(()=>fetchAccounts(true),80)).observe(list,{childList:true,subtree:true});
  const c=getClient();
  try{c?.auth.onAuthStateChange(()=>setTimeout(()=>fetchAccounts(true),100));}catch(_){}
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(boot,250));
else setTimeout(boot,250);

const style=document.createElement('style');
style.textContent=`
#nexa-constellation-system .nexa-account-planet{z-index:5}
#nexa-v593-passport{width:min(520px,calc(100% - 34px));margin:24px auto 80px;position:relative;z-index:8}
.nexa-v593-passport-card{display:grid;grid-template-columns:64px 1fr;gap:12px;align-items:center;padding:14px;border:1px solid rgba(119,87,246,.5);border-radius:20px;background:rgba(13,18,42,.84)}
.nexa-v593-passport-card img{width:64px;height:64px;border-radius:50%}
.nexa-v593-passport-card div{display:grid;gap:3px;min-width:0}
.nexa-v593-passport-card span{font-size:10px;letter-spacing:.18em;color:#a98cff;font-weight:900}
.nexa-v593-passport-card strong{font-size:20px;color:white}
.nexa-v593-passport-card small{color:#9ca9c8}`;
document.head.appendChild(style);
})();
