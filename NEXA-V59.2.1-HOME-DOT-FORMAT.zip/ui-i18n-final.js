(function(){
 const L=()=>NEXA_I18N.device();
 const tr=(k)=>NEXA_I18N.t(L(),k);
 const MAP={
  "LIVE":"live","View Event":"viewEvent","Apply":"apply","Apply →":"apply",
  "View Prep":"viewPrep","Fill Prep":"fillPrep","Claim Account":"claimAccount",
  "State Assignments":"stateAssignments","Puzzle & Presidency":"puzzlePresidency",
  "Transfers":"transfers","TRANSFER":"transfers","Back Home":"backHome",
  "My Submissions":"mySubmissions","Admin":"admin"
 };
 function walk(){
   document.querySelectorAll("a,button,.badge,.pill,.eyebrow,.nav-link").forEach(el=>{
     const raw=(el.textContent||"").trim();
     if(MAP[raw] && !el.dataset.nexaUiI18n){
       el.textContent=tr(MAP[raw]) + (raw.endsWith("→")?" →":"");
       el.dataset.nexaUiI18n="1";
     }
   });
 }
 document.addEventListener("DOMContentLoaded",()=>{
   try{NEXA_I18N.setDir(L());walk();new MutationObserver(walk).observe(document.body,{childList:true,subtree:true});}catch(_){}
 });
})();


/* ==========================================================
   NEXA v59.2 — CONSTELLATION DOM MIRROR HARD FIX
   Reads the exact rendered WOS account cards by their Edit/Delete
   buttons, normalizes name/alliance/ID, and renders its own stable
   constellation UI so legacy CSS cannot hide the planets.
   ========================================================== */
(function(){
  'use strict';

  const $=id=>document.getElementById(id);
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[m]));

  let accounts=[];
  let selectedKey=null;
  let tapKey=null;
  let tapAt=0;

  function initials(name){
    const parts=String(name||'NEXA').trim().split(/\s+/).filter(Boolean);
    return (parts.length>1 ? parts[0][0]+parts[1][0] : (parts[0]||'NX').slice(0,2)).toUpperCase();
  }

  function avatarData(name){
    const t=initials(name);
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180">
      <defs><radialGradient id="g"><stop offset="0" stop-color="#314579"/><stop offset="1" stop-color="#111730"/></radialGradient></defs>
      <circle cx="90" cy="90" r="90" fill="url(#g)"/>
      <text x="50%" y="57%" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="62" fill="#cab6ff">${t}</text>
    </svg>`;
    return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
  }

  function findAccountCard(editButton,list){
    let node=editButton.parentElement;
    while(node && node!==list){
      const btns=[...node.querySelectorAll('button')].map(b=>(b.textContent||'').trim().toLowerCase());
      const edits=btns.filter(x=>x==='edit').length;
      const deletes=btns.filter(x=>x==='delete').length;
      const txt=(node.textContent||'').replace(/\s+/g,' ').trim();
      if(edits===1 && deletes===1 && /\bID\b/i.test(txt)) return node;
      node=node.parentElement;
    }
    return editButton.parentElement;
  }

  function parseCard(card,index){
    if(!card) return null;

    const edit=card.querySelector('button');
    const nameCandidates=[...card.querySelectorAll('strong,b,h3,h4,.account-name,.name')]
      .map(el=>(el.textContent||'').trim())
      .filter(Boolean)
      .filter(x=>!/^(edit|delete)$/i.test(x));

    let raw=(card.textContent||'')
      .replace(/\bEdit\b/gi,' ')
      .replace(/\bDelete\b/gi,' ')
      .replace(/\s+/g,' ')
      .trim();

    const idMatch=raw.match(/\bID\s*([0-9A-Za-z_-]+)/i);
    const playerId=idMatch?.[1]||'';

    let beforeId=idMatch ? raw.slice(0,idMatch.index).trim() : raw;
    beforeId=beforeId.replace(/[•·]\s*$/,'').trim();

    let name=nameCandidates[0]||'';
    let alliance='Not Listed';

    // Visible card structure is "Name" then "Alliance • ID ####".
    // If semantic name element exists, everything after it and before ID is alliance.
    if(name && beforeId.toLowerCase().startsWith(name.toLowerCase())){
      let rest=beforeId.slice(name.length).trim();
      rest=rest.replace(/^[•·\-–—:]+/,'').trim();
      if(rest) alliance=rest;
    }else{
      // Fallback: split using known alliance token immediately before bullet/ID.
      const spaced=beforeId.match(/^(.+?)\s+([^\s]+)$/);
      if(spaced){
        name=spaced[1].trim();
        alliance=spaced[2].trim();
      }else{
        name=beforeId || `Account ${index+1}`;
      }
    }

    // Remove accidental duplicated alliance from name.
    if(alliance!=='Not Listed' && name.toLowerCase().endsWith(alliance.toLowerCase()) && name.length>alliance.length){
      name=name.slice(0,-alliance.length).trim();
    }

    return {
      key:playerId || `${name}-${index}`,
      name:name || `Account ${index+1}`,
      playerId,
      alliance:alliance || 'Not Listed',
      isMain:index===0
    };
  }

  function readAccounts(){
    const list=$('accounts-list');
    if(!list) return [];

    const editButtons=[...list.querySelectorAll('button')]
      .filter(b=>(b.textContent||'').trim().toLowerCase()==='edit');

    const cards=[];
    const seen=new Set();

    editButtons.forEach(btn=>{
      const card=findAccountCard(btn,list);
      if(card && !seen.has(card)){
        seen.add(card);
        cards.push(card);
      }
    });

    return cards.map(parseCard).filter(Boolean);
  }

  function active(){
    if(!accounts.length) return null;
    const stored=localStorage.getItem('nexa_active_account_key');
    return accounts.find(a=>String(a.key)===String(stored)) || accounts[0];
  }

  function syncHome(){
    const a=active();
    if(!a) return;

    const img=$('nexa-profile-launcher-photo');
    const name=$('nexa-profile-launcher-name');
    const badge=$('nexa-profile-launcher-badge');
    const count=$('nexa-profile-launcher-count');

    if(img){ img.src=avatarData(a.name); img.style.display='block'; }
    if(name){
      const parts=[String(a.name||'').toUpperCase()];
      if(a.alliance && a.alliance!=='Not Listed') parts.push(String(a.alliance).toUpperCase());
      if(a.playerId) parts.push('ID '+a.playerId);
      name.textContent=parts.join(' • ');
    }
    if(badge) badge.textContent='MAIN';
    if(count){
      count.textContent=String(accounts.length);
      count.classList.toggle('hidden',accounts.length<2);
    }
  }

  function passport(a){
    selectedKey=a?.key||null;
    $('nexa-v592-passport')?.remove();
    const modal=$('nexa-account-constellation');
    if(!modal || !a) return;

    const section=document.createElement('section');
    section.id='nexa-v592-passport';
    section.innerHTML=`
      <div class="v592-passport">
        <img src="${avatarData(a.name)}" alt="">
        <div>
          <span>PROFILE PASSPORT</span>
          <strong>${esc(a.name)}</strong>
          <small>${esc(a.alliance)}${a.playerId?' • ID '+esc(a.playerId):''}</small>
        </div>
        <em>Double tap to switch account</em>
      </div>`;
    modal.appendChild(section);
  }

  function planet(a,isMain,left,top){
    const size=isMain?'42%':'22%';
    const border=isMain?'#9867ff':'#48c7ff';
    return `
      <button type="button" data-v592-account="${esc(a.key)}"
        style="position:absolute;left:${left}%;top:${top}%;width:${size};aspect-ratio:1/1;
        transform:translate(-50%,-50%);border-radius:50%;border:${isMain?'3':'2'}px solid ${border};
        background:radial-gradient(circle at 35% 30%,#314579 0,#151d3b 52%,#080c1d 100%);
        box-shadow:0 0 ${isMain?'30':'18'}px rgba(111,84,255,.28);z-index:${isMain?'6':'5'};
        display:flex;align-items:center;justify-content:center;padding:0;overflow:visible;color:white">
        <span style="font-size:${isMain?'clamp(28px,7vw,52px)':'clamp(16px,4vw,28px)'};
          color:#cab6ff;font-weight:900">${esc(initials(a.name))}</span>
        <span style="position:absolute;top:108%;left:50%;transform:translateX(-50%);
          white-space:nowrap;font-size:${isMain?'16':'12'}px;font-weight:900;letter-spacing:.05em">
          ${esc(a.name)}
        </span>
        ${isMain?'<span style="position:absolute;top:124%;left:50%;transform:translateX(-50%);font-size:10px;color:#a98cff;font-weight:900;letter-spacing:.16em">MAIN</span>':''}
      </button>`;
  }

  function render(){
    const system=$('nexa-constellation-system');
    if(!system) return;

    const a=active();
    const orbiting=a?accounts.filter(x=>x.key!==a.key):[];
    const positions=[[18,30],[82,30],[82,72],[18,72]];

    system.style.position='relative';
    system.style.display='block';
    system.style.width='min(82vw,520px)';
    system.style.height='min(82vw,520px)';
    system.style.maxWidth='520px';
    system.style.maxHeight='520px';
    system.style.margin='70px auto 0';
    system.style.overflow='visible';

    let html=
      '<span style="position:absolute;inset:8%;border:1px solid rgba(123,117,194,.18);border-radius:50%;pointer-events:none"></span>'+
      '<span style="position:absolute;inset:-12%;border:1px dashed rgba(83,190,255,.13);border-radius:50%;pointer-events:none;animation:v592Orbit 28s linear infinite"></span>';

    if(a) html+=planet(a,true,50,50);

    orbiting.slice(0,4).forEach((x,i)=>{
      const p=positions[i];
      html+=planet(x,false,p[0],p[1]);
    });

    if(accounts.length<5){
      const p=positions[Math.min(orbiting.length,3)]||[50,14];
      html+=`
        <button type="button" id="nexa-v592-add"
          style="position:absolute;left:${p[0]}%;top:${p[1]}%;width:20%;aspect-ratio:1/1;
          transform:translate(-50%,-50%);border-radius:50%;border:2px solid #429ac8;
          background:#0b1730;color:#69d7ff;z-index:7;font-size:40px;display:flex;
          align-items:center;justify-content:center;overflow:visible">
          +
          <span style="position:absolute;top:112%;left:50%;transform:translateX(-50%);
          white-space:nowrap;color:white;font-size:12px;font-weight:900">ADD ACCOUNT</span>
        </button>`;
    }

    system.innerHTML=html;
    $('nexa-constellation-manage')?.style && ($('nexa-constellation-manage').style.display='none');

    if(a && !selectedKey) passport(a);
  }

  function hydrate(){
    const found=readAccounts();
    if(!found.length) return false;
    accounts=found;
    syncHome();
    if($('nexa-account-constellation')?.classList.contains('open')) render();
    return true;
  }

  function ensureAccountsThenRender(){
    if(hydrate()){
      render();
      return;
    }

    const accountsModal=$('accounts-modal');
    const wasOpen=accountsModal?.classList.contains('open');

    if(accountsModal && !wasOpen){
      accountsModal.style.visibility='hidden';
      accountsModal.style.pointerEvents='none';
      accountsModal.classList.add('open');
      accountsModal.setAttribute('aria-hidden','false');
    }

    let tries=0;
    const wait=()=>{
      tries++;
      if(hydrate() || tries>30){
        if(accountsModal && !wasOpen){
          accountsModal.classList.remove('open');
          accountsModal.setAttribute('aria-hidden','true');
          accountsModal.style.visibility='';
          accountsModal.style.pointerEvents='';
        }
        render();
        return;
      }
      setTimeout(wait,120);
    };
    setTimeout(wait,120);
  }

  function openConstellation(){
    const modal=$('nexa-account-constellation');
    if(!modal) return;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
    selectedKey=null;
    ensureAccountsThenRender();
  }

  function openAdd(){
    $('nexa-account-constellation')?.classList.remove('open');
    const modal=$('accounts-modal');
    if(modal){
      modal.style.visibility='';
      modal.style.pointerEvents='';
      modal.classList.add('open');
      modal.setAttribute('aria-hidden','false');
    }
  }

  function switchAccount(key){
    const a=accounts.find(x=>String(x.key)===String(key));
    if(!a) return;
    localStorage.setItem('nexa_active_account_key',String(a.key));
    selectedKey=a.key;
    syncHome();
    render();
    passport(a);
  }

  document.addEventListener('click',e=>{
    if(e.target.closest?.('#nexa-profile-launcher')){
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      openConstellation(); return;
    }
    if(e.target.closest?.('#nexa-v592-add')){
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      openAdd(); return;
    }
    const p=e.target.closest?.('[data-v592-account]');
    if(p){
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      const key=p.getAttribute('data-v592-account');
      const a=accounts.find(x=>String(x.key)===String(key));
      const now=Date.now();
      if(tapKey===key && now-tapAt<450){
        tapKey=null; tapAt=0; switchAccount(key);
      }else{
        tapKey=key; tapAt=now; passport(a);
      }
    }
  },true);

  document.addEventListener('dblclick',e=>{
    const p=e.target.closest?.('[data-v592-account]');
    if(!p) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    switchAccount(p.getAttribute('data-v592-account'));
  },true);

  function watch(){
    const list=$('accounts-list');
    if(!list){ setTimeout(watch,250); return; }
    new MutationObserver(()=>setTimeout(hydrate,40))
      .observe(list,{childList:true,subtree:true,characterData:true});
    hydrate();
  }

  const style=document.createElement('style');
  style.textContent=`
    @keyframes v592Orbit{to{transform:rotate(360deg)}}
    #nexa-v592-passport{width:min(520px,calc(100% - 34px));margin:30px auto 80px;position:relative;z-index:10}
    .v592-passport{display:grid;grid-template-columns:64px 1fr;gap:12px;align-items:center;padding:14px;
      border:1px solid rgba(119,87,246,.5);border-radius:20px;background:rgba(13,18,42,.88)}
    .v592-passport img{width:64px;height:64px;border-radius:50%;border:2px solid rgba(111,201,255,.65)}
    .v592-passport div{display:grid;gap:3px;min-width:0}
    .v592-passport span{font-size:10px;letter-spacing:.18em;color:#a98cff;font-weight:900}
    .v592-passport strong{font-size:20px;color:white}
    .v592-passport small{color:#9ca9c8}
    .v592-passport em{grid-column:1/-1;text-align:center;color:#69d7ff;font-size:11px;font-style:normal;text-transform:uppercase;letter-spacing:.08em}
  `;
  document.head.appendChild(style);

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(watch,250));
  else setTimeout(watch,250);
})();
