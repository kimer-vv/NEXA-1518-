(function(){
 const L=()=>NEXA_I18N.device();
 const tr=(k)=>NEXA_I18N.t(L(),k);
 const MAP={
  "LIVE":"live","View Event":"viewEvent","Apply":"apply","Apply →":"apply",
  "View Prep":"viewPrep","Fill Prep":"fillPrep","Claim Account":"claimAccount",
  "State Assignments":"stateAssignments","Puzzle & Presidency":"puzzlePresidency",
  "Transfers":"transfers","TRANSFER":"transfers","Back Home":"backHome",
  "My Submissions":"mySubmissions","Admin":"admin"
 };
 function walk(){
   document.querySelectorAll("a,button,.badge,.pill,.eyebrow,.nav-link").forEach(el=>{
     const raw=(el.textContent||"").trim();
     if(MAP[raw] && !el.dataset.nexaUiI18n){
       el.textContent=tr(MAP[raw]) + (raw.endsWith("→")?" →":"");
       el.dataset.nexaUiI18n="1";
     }
   });
   document.querySelectorAll("h1,h2,h3,p,div,span").forEach(el=>{
     if(el.children.length) return;
     const s=(el.textContent||"").trim();
     const m=s.match(/^SvS against\s+(.+)$/i);
     if(m && !el.dataset.nexaUiI18n){
       el.textContent=tr("svsAgainst").replace("{state}",m[1]);
       el.dataset.nexaUiI18n="1";
     }
   });
 }
 document.addEventListener("DOMContentLoaded",()=>{
   NEXA_I18N.setDir(L()); walk();
   new MutationObserver(walk).observe(document.body,{childList:true,subtree:true});
 });
})();

/* =========================================================
   NEXA v58.2 — PROFILE / CONSTELLATION / ALLIANCES FIX
   Loaded after lang.js so this safely overrides the old mobile
   profile handlers without touching the working HOME / TOOLS.
   ========================================================= */
(function(){
  'use strict';

  const PROJECT_URL='https://dfxcxboxrkfmrnsgpyin.supabase.co';
  const PROJECT_KEY='sb_publishable_HTd6T3L8WuN_owZwPUjE1Q_glB9YWM-';
  const $=id=>document.getElementById(id);
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[m]));

  function sbClient(){
    if(window.supabaseClient?.auth) return window.supabaseClient;
    if(window.__nexaProfileSb) return window.__nexaProfileSb;
    if(window.supabase?.createClient){
      window.__nexaProfileSb=window.supabase.createClient(PROJECT_URL,PROJECT_KEY);
      return window.__nexaProfileSb;
    }
    return null;
  }

  async function getUser(){
    const sb=sbClient();
    if(!sb) return null;
    try{
      const {data}=await sb.auth.getUser();
      return data?.user||null;
    }catch(_){
      return null;
    }
  }

  async function loadMyAccounts(){
    const sb=sbClient();
    const user=await getUser();
    if(!sb||!user) return [];

    try{
      const {data,error}=await sb
        .from('player_accounts')
        .select('*')
        .eq('user_id',user.id)
        .order('is_main',{ascending:false})
        .order('created_at',{ascending:true});

      if(error) throw error;
      return data||[];
    }catch(error){
      console.warn('NEXA v58.2 accounts:',error?.message||error);
      return [];
    }
  }

  function avatar(account){
    return account?.profile_photo_url ||
      'https://ui-avatars.com/api/?name='+
      encodeURIComponent(account?.in_game_name||'NEXA')+
      '&background=111a38&color=cabaff&bold=true&size=256';
  }

  function renderConstellation(accounts){
    const system=$('nexa-constellation-system');
    if(!system) return;

    const rows=Array.isArray(accounts)?accounts.filter(Boolean):[];
    const main=rows.find(a=>a.is_main===true)||rows[0]||null;
    const others=main ? rows.filter(a=>String(a.id)!==String(main.id)) : [];
    const positions=[[18,28],[82,30],[84,68],[50,86],[16,68]];

    /* V59.1: make Constellation self-contained instead of depending on
       legacy constellation CSS/markup. This is intentionally inline so
       mobile Safari cannot hide the account planets through stale rules. */
    system.style.position='relative';
    system.style.width='min(82vw,520px)';
    system.style.height='min(82vw,520px)';
    system.style.maxWidth='520px';
    system.style.maxHeight='520px';
    system.style.margin='64px auto 0';
    system.style.overflow='visible';
    system.style.display='block';

    let html=
      '<span style="position:absolute;inset:7%;border:1px solid rgba(123,117,194,.20);border-radius:50%;pointer-events:none"></span>'+
      '<span style="position:absolute;inset:-12%;border:1px dashed rgba(79,181,255,.12);border-radius:50%;pointer-events:none;animation:nexaV591Orbit 24s linear infinite"></span>';

    const planet=(account,kind,left,top,label)=>{
      const isMain=kind==='main';
      const size=isMain?'42%':'22%';
      const transform='translate(-50%,-50%)';
      return '<button type="button" data-v591-account="'+esc(account.id)+'" '+
        'style="position:absolute;left:'+left+'%;top:'+top+'%;width:'+size+';aspect-ratio:1/1;'+
        'transform:'+transform+';border-radius:50%;border:'+(isMain?'3px':'2px')+' solid '+(isMain?'#9b6cff':'#45bff2')+';'+
        'background:radial-gradient(circle at 35% 30%,#26376a 0,#111936 55%,#080d20 100%);'+
        'box-shadow:0 0 '+(isMain?'28px':'18px')+' rgba(116,82,255,.28);padding:0;z-index:'+(isMain?'5':'4')+';'+
        'display:flex;align-items:center;justify-content:center;cursor:pointer;overflow:visible">'+
          '<span style="font-weight:900;font-size:'+(isMain?'clamp(26px,7vw,52px)':'clamp(15px,4vw,28px)')+';color:#cdb7ff;letter-spacing:.04em">'+
            esc((account.in_game_name||'NEXA').slice(0,2).toUpperCase())+
          '</span>'+
          '<span style="position:absolute;top:106%;left:50%;transform:translateX(-50%);white-space:nowrap;color:#f2f3ff;font-size:'+(isMain?'16px':'12px')+';font-weight:800;letter-spacing:.06em">'+
            esc(account.in_game_name||label)+
          '</span>'+
          (isMain?'<span style="position:absolute;top:122%;left:50%;transform:translateX(-50%);color:#aa8cff;font-size:10px;font-weight:800;letter-spacing:.18em">MAIN</span>':'')+
        '</button>';
    };

    if(main) html+=planet(main,'main',50,50,'Main Account');

    others.slice(0,4).forEach((account,index)=>{
      const p=positions[index];
      html+=planet(account,'alt',p[0],p[1],'Account');
    });

    if(rows.length<5){
      const p=positions[Math.min(others.length,positions.length-1)];
      html+='<button type="button" id="nexa-v591-add-account" '+
        'style="position:absolute;left:'+p[0]+'%;top:'+p[1]+'%;width:20%;aspect-ratio:1/1;transform:translate(-50%,-50%);'+
        'border-radius:50%;border:2px solid #3c9dcc;background:#0b1730;color:#64d5ff;z-index:6;font-size:42px;line-height:1;'+
        'display:flex;align-items:center;justify-content:center;overflow:visible">'+
          '<span>+</span>'+
          '<span style="position:absolute;top:112%;left:50%;transform:translateX(-50%);white-space:nowrap;color:#f2f3ff;font-size:12px;font-weight:900;letter-spacing:.05em">ADD ACCOUNT</span>'+
        '</button>';
    }

    system.innerHTML=html;

    if(!document.getElementById('nexa-v591-style')){
      const style=document.createElement('style');
      style.id='nexa-v591-style';
      style.textContent='@keyframes nexaV591Orbit{to{transform:rotate(360deg)}}';
      document.head.appendChild(style);
    }

    const legacyManage=$('nexa-constellation-manage');
    if(legacyManage) legacyManage.style.display='none';
  }

  async function openConstellation(){
    const modal=$('nexa-account-constellation');
    if(!modal) return;

    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');

    let rows=await loadMyAccounts();
    if(!rows.length){
      await new Promise(resolve=>setTimeout(resolve,350));
      rows=await loadMyAccounts();
    }
    renderConstellation(rows);
  }

  function findAllianceSelect(){
    return $('alliance-select') ||
      $('alliance') ||
      document.querySelector('#accounts-modal select[name="alliance_id"]') ||
      Array.from(document.querySelectorAll('#accounts-modal select')).find(select=>{
        const key=((select.id||'')+' '+(select.name||'')).toLowerCase();
        return key.includes('alliance');
      });
  }

  async function populateAlliances(){
    const sb=sbClient();
    const select=findAllianceSelect();
    if(!sb||!select) return;

    select.innerHTML='<option value="">Loading alliances...</option>';

    try{
      const {data,error}=await sb
        .from('alliances')
        .select('id,tag')
        .eq('is_active',true)
        .order('tag');

      if(error) throw error;

      select.innerHTML=
        '<option value="">Select alliance</option>'+
        (data||[]).map(a=>
          '<option value="'+esc(a.id)+'">'+esc(a.tag)+'</option>'
        ).join('')+
        '<option value="not-listed">Not Listed</option>';
    }catch(error){
      console.warn('NEXA v58.2 alliances:',error?.message||error);
      select.innerHTML=
        '<option value="">Alliance unavailable</option>'+
        '<option value="not-listed">Not Listed</option>';
    }
  }

  function fixTimezone(){
    const zone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';
    const display=$('timezone-display');
    const offset=$('timezone-offset');

    if(display) display.textContent=zone;

    if(offset){
      try{
        const part=new Intl.DateTimeFormat('en-US',{
          timeZone:zone,
          timeZoneName:'shortOffset',
          hour:'2-digit'
        }).formatToParts(new Date()).find(p=>p.type==='timeZoneName');

        offset.textContent=(part?.value||'').replace('GMT','UTC');
      }catch(_){
        offset.textContent='';
      }
    }
  }

  async function openAddAccount(){
    const constellation=$('nexa-account-constellation');
    if(constellation){
      constellation.classList.remove('open');
      constellation.setAttribute('aria-hidden','true');
    }

    const modal=$('accounts-modal');
    if(modal){
      modal.classList.add('open');
      modal.setAttribute('aria-hidden','false');
    }

    fixTimezone();
    await populateAlliances();
  }

  async function getAllianceTag(account){
    if(account?.custom_alliance_tag) return account.custom_alliance_tag;
    if(!account?.alliance_id) return 'Not Listed';

    const sb=sbClient();
    if(!sb) return 'Not Listed';

    try{
      const {data}=await sb
        .from('alliances')
        .select('tag')
        .eq('id',account.alliance_id)
        .maybeSingle();

      return data?.tag||'Not Listed';
    }catch(_){
      return 'Not Listed';
    }
  }

  async function openAccountProfile(accountId){
    const rows=await loadMyAccounts();
    const account=rows.find(a=>String(a.id)===String(accountId));
    if(!account) return;

    const setText=(id,value)=>{
      const el=$(id);
      if(el) el.textContent=value;
    };

    setText('nexa-profile-name',(account.in_game_name||'PLAYER').toUpperCase());
    setText('nexa-profile-player-id',account.player_id||'');
    setText('nexa-profile-alliance',await getAllianceTag(account));
    setText('nexa-profile-role',account.alliance_role||'R3');
    setText('nexa-profile-type',
      account.is_main===true
        ? 'MAIN'
        : (String(account.account_purpose||'full').toLowerCase()==='full'?'FULL':'BASIC')
    );
    setText('nexa-profile-furnace',account.furnace_level||'—');
    setText('nexa-profile-power',
      account.power ? Number(account.power).toLocaleString() : '—'
    );
    setText('nexa-profile-deployment',
      account.deployment_capacity
        ? Number(account.deployment_capacity).toLocaleString()
        : '—'
    );

    const photo=$('nexa-profile-photo');
    if(photo) photo.src=avatar(account);

    const constellation=$('nexa-account-constellation');
    if(constellation){
      constellation.classList.remove('open');
      constellation.setAttribute('aria-hidden','true');
    }

    const profile=$('nexa-profile-modal');
    if(profile){
      profile.classList.add('open');
      profile.setAttribute('aria-hidden','false');
    }
  }

  function replaceProfileLauncher(){
    const old=$('nexa-profile-launcher');
    if(!old || old.dataset.v582==='1') return;

    const fresh=old.cloneNode(true);
    fresh.dataset.v582='1';
    old.replaceWith(fresh);

    fresh.addEventListener('click',event=>{
      event.preventDefault();
      event.stopImmediatePropagation();
      openConstellation();
    },true);
  }

  function install(){
    replaceProfileLauncher();
    fixTimezone();

    document.addEventListener('click',event=>{
      const add=event.target.closest?.('#nexa-v591-add-account');
      if(add){
        event.preventDefault();
        event.stopImmediatePropagation();
        openAddAccount();
        return;
      }

      const planet=event.target.closest?.('[data-v591-account]');
      if(planet){
        event.preventDefault();
        event.stopImmediatePropagation();
        openAccountProfile(planet.getAttribute('data-v591-account'));
      }
    },true);

    setTimeout(replaceProfileLauncher,500);
    setTimeout(fixTimezone,600);
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',install);
  }else{
    install();
  }
})();
