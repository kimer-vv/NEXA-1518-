
-- ============================================================
-- NEXA v29.1 — Transfer Admin Repair
-- Run this ONCE in Supabase SQL Editor before uploading v29.1.
-- It is safe to run even if some earlier Transfer SQL was already run.
-- ============================================================

-- ---------- Transfer Event fields ----------
alter table public.transfer_events
  add column if not exists special_power_cap bigint,
  add column if not exists ended_at timestamptz,
  add column if not exists leadership_status text not null default 'not_leading',
  add column if not exists special_invites_available smallint not null default 0,
  add column if not exists keep_form_open_after_end boolean not null default false;

alter table public.transfer_events
  drop constraint if exists transfer_leadership_status_check;

alter table public.transfer_events
  add constraint transfer_leadership_status_check
  check (
    leadership_status in (
      'not_leading',
      'leading_no_specials',
      'leading_with_specials'
    )
  );

alter table public.transfer_events
  drop constraint if exists transfer_special_invites_available_check;

alter table public.transfer_events
  add constraint transfer_special_invites_available_check
  check (special_invites_available between 0 and 3);

alter table public.transfer_events
  drop constraint if exists transfer_special_power_cap_nonnegative;

alter table public.transfer_events
  add constraint transfer_special_power_cap_nonnegative
  check (special_power_cap is null or special_power_cap >= 0);


-- ---------- Transfer Application fields ----------
alter table public.transfer_applications
  add column if not exists submitted_after_event_end boolean not null default false;

alter table public.transfer_applications
  drop constraint if exists reduce_power_check;

alter table public.transfer_applications
  add constraint reduce_power_check
  check (
    willing_to_reduce_power in (
      'yes',
      'no',
      'need_amount',
      'not_sure',
      'review_first'
    )
  );


-- ============================================================
-- EXISTING ALLIANCES FOR TRANSFER STAFF
-- Avoids RLS preventing the Existing Alliance dropdown from loading.
-- ============================================================
create or replace function public.list_transfer_alliances()
returns table(
  id bigint,
  tag text
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.can_manage_transfers() then
    raise exception 'Transfer Staff access required.';
  end if;

  return query
  select a.id, a.tag
  from public.alliances a
  where coalesce(a.is_active,true)=true
  order by a.tag;
end;
$$;

grant execute
on function public.list_transfer_alliances()
to authenticated;


-- ============================================================
-- TRANSFER PERMISSION USERS
-- Always includes the authenticated Owner/Admin and lets Owner/Admin
-- search by Discord/name, IGN or Player ID.
-- ============================================================
create or replace function public.list_transfer_permission_users(
  search_text text default null
)
returns table(
  user_id uuid,
  discord_name text,
  role text,
  accounts jsonb
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_admin() then
    raise exception 'Admin access required.';
  end if;

  return query
  with roles as (
    select ur.user_id, max(ur.role)::text as role
    from public.user_roles ur
    group by ur.user_id
  ),
  account_data as (
    select
      pa.user_id,
      jsonb_agg(
        jsonb_build_object(
          'in_game_name', pa.in_game_name,
          'player_id', pa.player_id,
          'alliance', coalesce(a.tag, pa.custom_alliance_tag, 'Not Listed')
        )
        order by pa.in_game_name
      ) as accounts
    from public.player_accounts pa
    left join public.alliances a on a.id=pa.alliance_id
    group by pa.user_id
  )
  select
    u.id,
    coalesce(
      u.raw_user_meta_data->>'full_name',
      u.raw_user_meta_data->>'name',
      u.raw_user_meta_data->>'preferred_username',
      u.raw_user_meta_data->>'user_name',
      u.email,
      'Discord User'
    )::text,
    coalesce(r.role,'player')::text,
    coalesce(ad.accounts,'[]'::jsonb)
  from auth.users u
  left join roles r on r.user_id=u.id
  left join account_data ad on ad.user_id=u.id
  where
    u.id=auth.uid()
    or search_text is null
    or trim(search_text)=''
    or lower(coalesce(
      u.raw_user_meta_data->>'full_name',
      u.raw_user_meta_data->>'name',
      u.raw_user_meta_data->>'preferred_username',
      u.raw_user_meta_data->>'user_name',
      u.email,
      ''
    )) like '%'||lower(trim(search_text))||'%'
    or exists (
      select 1
      from public.player_accounts p2
      where p2.user_id=u.id
        and (
          lower(coalesce(p2.in_game_name,'')) like '%'||lower(trim(search_text))||'%'
          or lower(coalesce(p2.player_id::text,'')) like '%'||lower(trim(search_text))||'%'
        )
    )
  order by
    case coalesce(r.role,'player')
      when 'owner' then 0
      when 'admin' then 1
      when 'scheduler' then 2
      else 3
    end,
    2;
end;
$$;

grant execute
on function public.list_transfer_permission_users(text)
to authenticated;


-- ============================================================
-- SAVE RECRUITING ALLIANCE
-- Existing alliance OR a new tag.
-- ============================================================
create or replace function public.save_transfer_recruiting_alliance(
  p_transfer_event_id uuid,
  p_alliance_id bigint default null,
  p_new_tag text default null,
  p_is_recruiting boolean default true,
  p_schedule_notes text default null
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_alliance_id bigint;
  v_row_id bigint;
begin
  if not public.can_manage_transfers() then
    raise exception 'Transfer Staff access required.';
  end if;

  v_alliance_id := p_alliance_id;

  if coalesce(trim(p_new_tag),'')<>'' then
    select a.id
    into v_alliance_id
    from public.alliances a
    where lower(a.tag)=lower(trim(p_new_tag))
    limit 1;

    if v_alliance_id is null then
      insert into public.alliances(tag,is_active)
      values(upper(trim(p_new_tag)),true)
      returning id into v_alliance_id;
    else
      update public.alliances
      set is_active=true
      where id=v_alliance_id;
    end if;
  end if;

  if v_alliance_id is null then
    raise exception 'Choose an existing alliance or enter a new Alliance Tag.';
  end if;

  insert into public.transfer_recruiting_alliances(
    transfer_event_id,
    alliance_id,
    is_recruiting,
    schedule_notes
  )
  values(
    p_transfer_event_id,
    v_alliance_id,
    p_is_recruiting,
    p_schedule_notes
  )
  on conflict(transfer_event_id,alliance_id)
  do update set
    is_recruiting=excluded.is_recruiting,
    schedule_notes=excluded.schedule_notes
  returning id into v_row_id;

  return v_row_id;
end;
$$;

grant execute
on function public.save_transfer_recruiting_alliance(uuid,bigint,text,boolean,text)
to authenticated;


-- ============================================================
-- PUBLIC TRANSFER EVENT + RECRUITING ALLIANCES
-- ============================================================
create or replace function public.get_public_transfer_event(
  p_event_token uuid
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  e public.transfer_events;
  alliances_json jsonb;
begin
  select *
  into e
  from public.transfer_events
  where public_token=p_event_token
    and applications_open=true
  limit 1;

  if e.id is null then
    return null;
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id',tra.id,
        'alliance_id',tra.alliance_id,
        'tag',a.tag,
        'schedule_notes',tra.schedule_notes,
        'is_recruiting',tra.is_recruiting
      )
      order by tra.sort_order,a.tag
    ),
    '[]'::jsonb
  )
  into alliances_json
  from public.transfer_recruiting_alliances tra
  join public.alliances a on a.id=tra.alliance_id
  where tra.transfer_event_id=e.id
    and tra.is_recruiting=true;

  return jsonb_build_object(
    'id',e.id,
    'title',e.title,
    'destination_state',e.destination_state,
    'status',e.status,
    'applications_open',e.applications_open,
    'power_cap',e.power_cap,
    'special_power_cap',e.special_power_cap,
    'leadership_status',e.leadership_status,
    'special_invites_available',e.special_invites_available,
    'keep_form_open_after_end',e.keep_form_open_after_end,
    'starts_at',e.starts_at,
    'ends_at',e.ends_at,
    'ended_at',e.ended_at,
    'public_notes',e.public_notes,
    'public_token',e.public_token,
    'recruiting_alliances',alliances_json
  );
end;
$$;

grant execute
on function public.get_public_transfer_event(uuid)
to anon,authenticated;


-- ============================================================
-- END EVENT EARLY / ON DEMAND
-- ============================================================
create or replace function public.end_transfer_event(
  p_transfer_event_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  keep_open boolean;
begin
  if not public.can_manage_transfers() then
    raise exception 'Transfer Staff access required.';
  end if;

  select keep_form_open_after_end
  into keep_open
  from public.transfer_events
  where id=p_transfer_event_id;

  if keep_open is null then
    raise exception 'Transfer Event not found.';
  end if;

  update public.transfer_events
  set
    status='archived',
    applications_open=keep_open,
    ended_at=now(),
    updated_at=now()
  where id=p_transfer_event_id;
end;
$$;

grant execute
on function public.end_transfer_event(uuid)
to authenticated;


-- ============================================================
-- OWNER-ONLY DELETE FROM TRANSFER HISTORY
-- ============================================================
create or replace function public.owner_delete_transfer_event(
  p_transfer_event_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_owner() then
    raise exception 'Owner access required.';
  end if;

  if not exists(
    select 1
    from public.transfer_events
    where id=p_transfer_event_id
      and status='archived'
  ) then
    raise exception 'Only archived Transfer Events can be permanently deleted.';
  end if;

  delete from public.transfer_events
  where id=p_transfer_event_id;
end;
$$;

grant execute
on function public.owner_delete_transfer_event(uuid)
to authenticated;
