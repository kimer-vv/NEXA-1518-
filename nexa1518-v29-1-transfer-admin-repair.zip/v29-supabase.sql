
-- ============================================================
-- NEXA v29 — Transfer Cycle Logic + Public Recruiting Fix
-- Run once in Supabase SQL Editor BEFORE uploading the ZIP.
-- ============================================================

alter table public.transfer_events
  add column if not exists leadership_status text not null default 'not_leading',
  add column if not exists special_invites_available smallint not null default 0,
  add column if not exists keep_form_open_after_end boolean not null default false;

alter table public.transfer_events
  drop constraint if exists transfer_leadership_status_check;

alter table public.transfer_events
  add constraint transfer_leadership_status_check
  check (leadership_status in ('not_leading','leading_under_3m','leading_3m_plus'));

alter table public.transfer_events
  drop constraint if exists transfer_special_invites_available_check;

alter table public.transfer_events
  add constraint transfer_special_invites_available_check
  check (special_invites_available between 0 and 3);

alter table public.transfer_applications
  add column if not exists submitted_after_event_end boolean not null default false;

-- v28.9 introduced "review_first" in the form.
alter table public.transfer_applications
  drop constraint if exists reduce_power_check;

alter table public.transfer_applications
  add constraint reduce_power_check
  check (
    willing_to_reduce_power in (
      'yes',
      'no',
      'need_amount',
      'not_sure',
      'review_first'
    )
  );

-- ------------------------------------------------------------
-- PUBLIC TRANSFER EVENT RPC
-- This avoids RLS/join issues that prevented Recruiting Alliances
-- from appearing on the public form.
-- ------------------------------------------------------------
create or replace function public.get_public_transfer_event(
  p_event_token uuid
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  e public.transfer_events;
  alliances_json jsonb;
begin
  select *
  into e
  from public.transfer_events
  where public_token = p_event_token
    and applications_open = true
  limit 1;

  if e.id is null then
    return null;
  end if;

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', tra.id,
        'alliance_id', tra.alliance_id,
        'tag', a.tag,
        'schedule_notes', tra.schedule_notes,
        'is_recruiting', tra.is_recruiting
      )
      order by tra.sort_order, a.tag
    ),
    '[]'::jsonb
  )
  into alliances_json
  from public.transfer_recruiting_alliances tra
  join public.alliances a on a.id = tra.alliance_id
  where tra.transfer_event_id = e.id
    and tra.is_recruiting = true;

  return jsonb_build_object(
    'id', e.id,
    'title', e.title,
    'destination_state', e.destination_state,
    'status', e.status,
    'applications_open', e.applications_open,
    'power_cap', e.power_cap,
    'special_power_cap', e.special_power_cap,
    'leadership_status', e.leadership_status,
    'special_invites_available', e.special_invites_available,
    'keep_form_open_after_end', e.keep_form_open_after_end,
    'starts_at', e.starts_at,
    'ends_at', e.ends_at,
    'ended_at', e.ended_at,
    'public_notes', e.public_notes,
    'public_token', e.public_token,
    'recruiting_alliances', alliances_json
  );
end;
$$;

grant execute
on function public.get_public_transfer_event(uuid)
to anon, authenticated;

-- ------------------------------------------------------------
-- END TRANSFER EVENT
-- Can end early. The form can optionally remain open for future
-- interest/waitlist applications.
-- ------------------------------------------------------------
create or replace function public.end_transfer_event(
  p_transfer_event_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  keep_open boolean;
begin
  if not public.can_manage_transfers() then
    raise exception 'Transfer Staff access required.';
  end if;

  select keep_form_open_after_end
  into keep_open
  from public.transfer_events
  where id = p_transfer_event_id;

  if keep_open is null then
    raise exception 'Transfer Event not found.';
  end if;

  update public.transfer_events
  set
    status = 'archived',
    applications_open = keep_open,
    ended_at = now(),
    updated_at = now()
  where id = p_transfer_event_id;
end;
$$;

grant execute
on function public.end_transfer_event(uuid)
to authenticated;

-- ------------------------------------------------------------
-- PUBLIC APPLICATION SUBMISSION
-- Form may remain open after the active cycle ends.
-- Labyrinth is flagged based on Special Invite Power Cap,
-- not a separate threshold field.
-- ------------------------------------------------------------
create or replace function public.submit_transfer_application(
  p_event_token uuid,
  p_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_event public.transfer_events;
  v_id uuid;
  v_application_id text;
  v_existing_count integer;
  v_power bigint;
  v_after_end boolean;
begin
  select *
  into v_event
  from public.transfer_events
  where public_token = p_event_token
    and applications_open = true
  limit 1;

  if v_event.id is null then
    raise exception 'Transfer applications are currently closed.';
  end if;

  if coalesce(trim(p_payload ->> 'in_game_name'),'') = '' then
    raise exception 'In-game name is required.';
  end if;

  if coalesce(trim(p_payload ->> 'player_id'),'') = '' then
    raise exception 'Player ID is required.';
  end if;

  if coalesce(trim(p_payload ->> 'current_state'),'') = '' then
    raise exception 'Current State is required.';
  end if;

  if coalesce(trim(p_payload ->> 'current_power'),'') = '' then
    raise exception 'Current Power is required.';
  end if;

  v_power := (p_payload ->> 'current_power')::bigint;
  v_after_end := (v_event.status = 'archived' or v_event.ended_at is not null);

  select count(*)
  into v_existing_count
  from public.transfer_applications ta
  where ta.transfer_event_id = v_event.id
    and ta.player_id = trim(p_payload ->> 'player_id');

  insert into public.transfer_applications (
    transfer_event_id,
    completed_by,
    referred,
    referred_by,
    in_game_name,
    player_id,
    current_state,
    current_alliance,
    discord_username,
    furnace_level,
    current_power,
    t12_infantry,
    t12_lancer,
    t12_marksman,
    t11_infantry,
    t11_lancer,
    t11_marksman,
    willing_to_reduce_power,
    labyrinth_score,
    transfer_passes,
    preferred_alliance_ids,
    flexible_alliance,
    preferred_utc_ranges,
    discord_vc,
    transferring_with_group,
    group_name,
    group_leader,
    group_size,
    group_members_submitting,
    transfer_without_full_group,
    coordinates,
    additional_information,
    state_playstyle,
    confirms_information,
    confirms_interest_only,
    confirms_alliance_flexibility,
    submitted_after_event_end
  )
  values (
    v_event.id,
    coalesce(p_payload ->> 'completed_by','self'),
    coalesce((p_payload ->> 'referred')::boolean,false),
    nullif(trim(p_payload ->> 'referred_by'),''),
    trim(p_payload ->> 'in_game_name'),
    trim(p_payload ->> 'player_id'),
    (p_payload ->> 'current_state')::bigint,
    nullif(trim(p_payload ->> 'current_alliance'),''),
    nullif(trim(p_payload ->> 'discord_username'),''),
    p_payload ->> 'furnace_level',
    v_power,
    coalesce((p_payload ->> 't12_infantry')::boolean,false),
    coalesce((p_payload ->> 't12_lancer')::boolean,false),
    coalesce((p_payload ->> 't12_marksman')::boolean,false),
    coalesce((p_payload ->> 't11_infantry')::boolean,false),
    coalesce((p_payload ->> 't11_lancer')::boolean,false),
    coalesce((p_payload ->> 't11_marksman')::boolean,false),
    coalesce(p_payload ->> 'willing_to_reduce_power','not_sure'),
    case
      when nullif(p_payload ->> 'labyrinth_score','') is null then null
      else (p_payload ->> 'labyrinth_score')::bigint
    end,
    coalesce(p_payload ->> 'transfer_passes','not_sure'),
    coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_payload -> 'preferred_alliance_ids','[]'::jsonb)
        )::bigint
      ),
      '{}'
    ),
    coalesce((p_payload ->> 'flexible_alliance')::boolean,false),
    coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_payload -> 'preferred_utc_ranges','[]'::jsonb)
        )
      ),
      '{}'
    ),
    coalesce(p_payload ->> 'discord_vc','sometimes'),
    coalesce((p_payload ->> 'transferring_with_group')::boolean,false),
    nullif(trim(p_payload ->> 'group_name'),''),
    nullif(trim(p_payload ->> 'group_leader'),''),
    nullif(trim(p_payload ->> 'group_size'),''),
    nullif(trim(p_payload -> 'group_members_submitting' ->> 0),''),
    nullif(trim(p_payload -> 'transfer_without_full_group' ->> 0),''),
    nullif(trim(p_payload ->> 'coordinates'),''),
    nullif(trim(p_payload -> 'additional_information' ->> 0),''),
    nullif(trim(p_payload ->> 'state_playstyle'),''),
    coalesce((p_payload ->> 'confirms_information')::boolean,false),
    coalesce((p_payload ->> 'confirms_interest_only')::boolean,false),
    coalesce((p_payload ->> 'confirms_alliance_flexibility')::boolean,false),
    v_after_end
  )
  returning id into v_id;

  v_application_id :=
    'NEXA-TR-' ||
    upper(substr(replace(v_id::text,'-',''),1,8));

  update public.transfer_applications
  set application_id = v_application_id
  where id = v_id;

  return jsonb_build_object(
    'application_id', v_application_id,
    'duplicate', (v_existing_count > 0),
    'future_interest', v_after_end,
    'labyrinth_required',
      (
        v_event.special_power_cap is not null
        and v_power > v_event.special_power_cap
      )
  );
end;
$$;

grant execute
on function public.submit_transfer_application(uuid,jsonb)
to anon, authenticated;

-- ------------------------------------------------------------
-- Owner-only permanent delete remains available in History.
-- ------------------------------------------------------------
create or replace function public.owner_delete_transfer_event(
  p_transfer_event_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_owner() then
    raise exception 'Owner access required.';
  end if;

  if not exists (
    select 1
    from public.transfer_events
    where id = p_transfer_event_id
      and status = 'archived'
  ) then
    raise exception 'Only archived Transfer Events can be permanently deleted.';
  end if;

  delete from public.transfer_events
  where id = p_transfer_event_id;
end;
$$;

grant execute
on function public.owner_delete_transfer_event(uuid)
to authenticated;
