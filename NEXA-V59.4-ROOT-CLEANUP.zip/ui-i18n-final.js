(function(){
  const L=()=>NEXA_I18N.device();
  const tr=(k)=>NEXA_I18N.t(L(),k);
  const MAP={
    "LIVE":"live","View Event":"viewEvent","Apply":"apply","Apply →":"apply",
    "View Prep":"viewPrep","Fill Prep":"fillPrep","Claim Account":"claimAccount",
    "State Assignments":"stateAssignments","Puzzle & Presidency":"puzzlePresidency",
    "Transfers":"transfers","TRANSFER":"transfers","Back Home":"backHome",
    "My Submissions":"mySubmissions","Admin":"admin"
  };

  function walk(){
    document.querySelectorAll("a,button,.badge,.pill,.eyebrow,.nav-link").forEach(el=>{
      const raw=(el.textContent||"").trim();
      if(MAP[raw] && !el.dataset.nexaUiI18n){
        el.textContent=tr(MAP[raw]) + (raw.endsWith("→") ? " →" : "");
        el.dataset.nexaUiI18n="1";
      }
    });
  }

  document.addEventListener("DOMContentLoaded",()=>{
    try{
      NEXA_I18N.setDir(L());
      walk();
      new MutationObserver(walk).observe(document.body,{childList:true,subtree:true});
    }catch(_){}
  });
})();

/*
  NEXA v59.4 ROOT CLEANUP
  IMPORTANT:
  This file intentionally contains NO Account Constellation,
  My Profile, Supabase account, or launcher handlers.

  index.html already owns the canonical account runtime:
    - loadHomeAccountCards()
    - renderNexaConstellation()
    - nexaRecoverConstellationAccounts()
    - openNexaProfile()

  Previous ui-i18n-final.js patches were intercepting #nexa-profile-launcher
  in capture phase and preventing the canonical index.html runtime from running.
*/
